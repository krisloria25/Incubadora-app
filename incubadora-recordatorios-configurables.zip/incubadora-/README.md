# Incubadora

Aplicación Expo / React Native para registrar lotes de incubación de aves.

## Funciones incluidas
- Registro de lotes para gallina, codorniz, pato, ganso y pavo.
- Persistencia local de lotes y controles mediante AsyncStorage.
- Guía educativa orientativa de etapas del embrión de gallina.
- Registro manual de temperatura, humedad y observaciones por lote.
- Recordatorios locales programables por lote: la persona puede elegir una hora diaria o varias horas separadas por comas (formato 24 h). Se programa un aviso para revisar cuándo detener el volteo y otro para la fecha estimada de nacimiento; los días son orientativos y deben confirmarse para la especie y el equipo.
- Galería inicial con imágenes remotas de referencia (requiere Internet).
- Configuración de compilación Android APK mediante EAS Build.

## Generar un APK
1. Instalar Node.js y crear una cuenta en https://expo.dev/.
2. En la carpeta del proyecto ejecutar:
   ```bash
   npm install
   npm install -g eas-cli
   eas login
   eas build --platform android --profile preview
   ```
3. Seguir las indicaciones de EAS y descargar el APK desde el enlace de la compilación.

## Limitaciones importantes
- Los recordatorios son notificaciones locales, no alertas desde sensores. Se necesita conceder permisos y volver a programarlos si se reinstala la app o se cambia de teléfono.
- Los lotes se guardan en el dispositivo; todavía no hay sincronización en la nube ni cuenta de usuario.
- La galería usa URLs de imágenes remotas y necesita Internet. Revisar las imágenes y licencias antes de publicar la app.
- La guía del embrión es educativa y se refiere a gallina; no es un diagnóstico de viabilidad ni sustituye instrucciones específicas de especie y equipo.
- Las temperaturas, humedades y días son orientativos. Confirma parámetros con el fabricante de la incubadora y fuentes técnicas fiables.
