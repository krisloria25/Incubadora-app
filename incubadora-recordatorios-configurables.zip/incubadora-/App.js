import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert, Image, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { StatusBar } from 'expo-status-bar';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
});

const ESPECIES = {
  Gallina: { dias: 21, temp: '37.5 °C', humedad: '45–55% al inicio; 65–70% al nacer', voltear: '3–5 veces al día', parar: 18, emoji: '🐔' },
  Codorniz: { dias: 17, temp: '37.5 °C', humedad: '45–55% al inicio; 65–70% al nacer', voltear: '3–5 veces al día', parar: 14, emoji: '🐦' },
  Pato: { dias: 28, temp: '37.5 °C (según especie y equipo)', humedad: 'Seguir guía específica de la especie', voltear: 'Según guía de la especie', parar: 25, emoji: '🦆' },
  Ganso: { dias: 30, temp: '37.5 °C (según especie y equipo)', humedad: 'Seguir guía específica de la especie', voltear: 'Según guía de la especie', parar: 27, emoji: '🪿' },
  Pavo: { dias: 28, temp: '37.5 °C', humedad: '45–55% al inicio; 65–70% al nacer', voltear: '3–5 veces al día', parar: 25, emoji: '🦃' },
};
const FOTOS = [
  { titulo: 'Gallina', subtitulo: 'Ave adulta', emoji: '🐔', uri: 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=800&auto=format&fit=crop&q=80' },
  { titulo: 'Pollitos', subtitulo: 'Primeros días de vida', emoji: '🐥', uri: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?w=800&auto=format&fit=crop&q=80' },
  { titulo: 'Huevos', subtitulo: 'Antes de incubar', emoji: '🥚', uri: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?w=800&auto=format&fit=crop&q=80' },
  { titulo: 'Incubadora', subtitulo: 'Equipo y control', emoji: '🌡️', uri: 'https://images.unsplash.com/photo-1589927986089-35812388d1f4?w=800&auto=format&fit=crop&q=80' },
];
const ETAPAS_GALLINA = [
  { desde: 1, hasta: 3, titulo: 'Inicio del desarrollo', detalle: 'Comienza la división celular y se forman las estructuras iniciales del embrión.' },
  { desde: 4, hasta: 7, titulo: 'Corazón y circulación', detalle: 'Se desarrollan estructuras importantes y la circulación empieza a hacerse visible.' },
  { desde: 8, hasta: 11, titulo: 'Formación de órganos', detalle: 'Continúa la formación de órganos, pico y extremidades.' },
  { desde: 12, hasta: 14, titulo: 'Crecimiento', detalle: 'El embrión crece y aparecen plumas en desarrollo.' },
  { desde: 15, hasta: 17, titulo: 'Preparación para nacer', detalle: 'El pollito ocupa gran parte del huevo y sigue madurando.' },
  { desde: 18, hasta: 20, titulo: 'Etapa de nacimiento', detalle: 'En gallina suele detenerse el volteo alrededor del día 18 y se eleva la humedad según la guía del equipo.' },
  { desde: 21, hasta: 21, titulo: 'Eclosión estimada', detalle: 'El pollito puede empezar a picar la cáscara y salir. Los tiempos pueden variar.' },
];
const fechaHoy = () => new Date().toISOString().slice(0, 10);
const parseFecha = (s) => { const d = new Date(`${s}T12:00:00`); return Number.isNaN(d.getTime()) ? null : d; };
const diaIncubacion = (fecha) => { const d = parseFecha(fecha); if (!d) return 1; return Math.max(1, Math.floor((new Date(`${fechaHoy()}T12:00:00`) - d) / 86400000) + 1); };
const analizarHorarios = (texto) => {
  const partes = texto.split(',').map(x => x.trim()).filter(Boolean);
  if (!partes.length || partes.some(h => !/^([01]?\d|2[0-3]):[0-5]\d$/.test(h))) return null;
  return [...new Set(partes.map(h => { const [hh, mm] = h.split(':'); return `${hh.padStart(2, '0')}:${mm}`; }))].sort();
};

export default function App() {
  const [tab, setTab] = useState('Inicio');
  const [especie, setEspecie] = useState('Gallina');
  const [nombre, setNombre] = useState('');
  const [fecha, setFecha] = useState(fechaHoy());
  const [cantidad, setCantidad] = useState('');
  const [notas, setNotas] = useState('');
  const [lotes, setLotes] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [loteActivo, setLoteActivo] = useState('');
  const [temp, setTemp] = useState('37.5');
  const [humedad, setHumedad] = useState('50');
  const [registroNota, setRegistroNota] = useState('');
  const [horariosRecordatorio, setHorariosRecordatorio] = useState('08:00');

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem('incubadora_lotes_v2');
        if (saved) { const parsed = JSON.parse(saved); setLotes(parsed); if (parsed[0]) setLoteActivo(parsed[0].id); }
      } catch (e) { console.warn('No se pudieron cargar los lotes', e); }
      setCargando(false);
    })();
  }, []);
  useEffect(() => { if (!cargando) AsyncStorage.setItem('incubadora_lotes_v2', JSON.stringify(lotes)).catch(() => {}); }, [lotes, cargando]);

  const activo = lotes.find(l => l.id === loteActivo) || lotes[0];
  const diasTotal = activo ? (ESPECIES[activo.especie]?.dias || 21) : 21;
  const diaActual = activo ? diaIncubacion(activo.fecha) : 1;
  const etapa = ETAPAS_GALLINA.find(e => diaActual >= e.desde && diaActual <= e.hasta) || ETAPAS_GALLINA[0];

  async function pedirPermisos() {
    const p = await Notifications.requestPermissionsAsync();
    if (!p.granted) { Alert.alert('Permiso necesario', 'Activa las notificaciones en los ajustes del teléfono para recibir recordatorios.'); return false; }
    if (Platform.OS === 'android') await Notifications.setNotificationChannelAsync('incubacion', { name: 'Recordatorios de incubación', importance: Notifications.AndroidImportance.HIGH, vibrationPattern: [0, 250, 250, 250] });
    return true;
  }

  async function programarAvisos(lote) {
    const horarios = analizarHorarios(lote.horariosRecordatorio || '08:00');
    if (!horarios) {
      Alert.alert('Revisa los horarios', 'Escribe uno o varios horarios en formato 24 horas, separados por comas. Ejemplo: 08:00, 14:00, 20:00.');
      return;
    }
    const ok = await pedirPermisos();
    if (!ok) return;
    const data = ESPECIES[lote.especie] || ESPECIES.Gallina;
    for (const oldId of (lote.notificationIds || [])) await Notifications.cancelScheduledNotificationAsync(oldId).catch(() => {});
    const ids = [];
    const inicio = parseFecha(lote.fecha);
    if (!inicio) return;
    const ahora = new Date();
    let creadas = 0;
    const triggerFecha = async (fechaAviso, titulo, cuerpo) => {
      if (fechaAviso <= ahora) return;
      ids.push(await Notifications.scheduleNotificationAsync({
        content: { title: titulo, body: cuerpo, sound: true, data: { loteId: lote.id } },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: fechaAviso, ...(Platform.OS === 'android' ? { channelId: 'incubacion' } : {}) },
      }));
      creadas++;
    };
    // La persona decide una o varias horas. Se recuerda el volteo solo hasta el día anterior
    // al día configurado para detenerlo; los calendarios son orientativos y deben verificarse.
    for (let i = 0; i < Math.min(data.dias, data.parar - 1); i++) {
      for (const hora of horarios) {
        const [hh, mm] = hora.split(':').map(Number);
        const d = new Date(inicio); d.setDate(d.getDate() + i); d.setHours(hh, mm, 0, 0);
        await triggerFecha(d, `Incubadora · ${lote.nombre}`, `Día ${i + 1}: revisa el equipo. Si corresponde según la guía de ${lote.especie}, recuerda voltear los huevos.`);
      }
    }
    const horaAvisoEspecial = horarios[0] || '08:00';
    const [hEspecial, mEspecial] = horaAvisoEspecial.split(':').map(Number);
    const detener = new Date(inicio); detener.setDate(detener.getDate() + data.parar - 1); detener.setHours(hEspecial, mEspecial, 0, 0);
    await triggerFecha(detener, `Revisar volteo · ${lote.nombre}`, `Día ${data.parar}: revisa la guía específica de ${lote.especie} para confirmar si hoy debes detener el volteo y preparar la etapa de nacimiento.`);
    const nacimiento = new Date(inicio); nacimiento.setDate(nacimiento.getDate() + data.dias - 1); nacimiento.setHours(hEspecial, mEspecial, 0, 0);
    await triggerFecha(nacimiento, `Nacimiento estimado · ${lote.nombre}`, `Hoy es la fecha estimada de eclosión. Observa el proceso y evita abrir la incubadora innecesariamente.`);
    setLotes(prev => prev.map(l => l.id === lote.id ? { ...l, notificationIds: ids, horariosRecordatorio: horarios.join(', ') } : l));
    Alert.alert('Recordatorios programados 🔔', `Se programaron ${creadas} avisos para “${lote.nombre}” en estos horarios: ${horarios.join(', ')}. Los avisos de volteo terminan antes del día indicado para detenerlo. Comprueba que las notificaciones estén permitidas en el teléfono.`);
  }

  function agregarLote() {
    const d = parseFecha(fecha);
    if (!nombre.trim() || !d || !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) { Alert.alert('Revisa los datos', 'Escribe un nombre y una fecha válida con formato AAAA-MM-DD.'); return; }
    if (d > new Date(`${fechaHoy()}T23:59:59`)) { Alert.alert('Fecha incorrecta', 'La fecha de inicio no puede estar en el futuro.'); return; }
    const horarios = analizarHorarios(horariosRecordatorio);
    if (!horarios) { Alert.alert('Horarios no válidos', 'Usa el formato 24 horas y separa los horarios con comas. Ejemplo: 08:00, 14:00, 20:00.'); return; }
    const lote = { id: `${Date.now()}`, nombre: nombre.trim(), especie, fecha, cantidad: cantidad.trim(), notas: notas.trim(), horariosRecordatorio: horarios.join(', '), registros: [], estado: 'En incubación' };
    setLotes(prev => [lote, ...prev]); setLoteActivo(lote.id); setNombre(''); setCantidad(''); setNotas(''); setHorariosRecordatorio('08:00'); setTab('Inicio');
    Alert.alert('Lote guardado 🥚', `Se guardó “${lote.nombre}”. ¿Quieres activar recordatorios reales?`, [{ text: 'Después', style: 'cancel' }, { text: 'Activar avisos', onPress: () => programarAvisos(lote) }]);
  }

  function guardarRegistro() {
    if (!activo) { Alert.alert('Primero crea un lote', 'Registra un lote para añadir controles.'); return; }
    if (!temp.trim() || !humedad.trim() || Number.isNaN(Number(temp)) || Number.isNaN(Number(humedad))) { Alert.alert('Datos incompletos', 'Introduce temperatura y humedad numéricas.'); return; }
    const registro = { id: `${Date.now()}`, fecha: new Date().toISOString(), dia: diaActual, temperatura: temp, humedad, nota: registroNota.trim() };
    setLotes(prev => prev.map(l => l.id === activo.id ? { ...l, registros: [registro, ...(l.registros || [])] } : l));
    setRegistroNota(''); Alert.alert('Control guardado', 'El registro quedó guardado en este dispositivo.');
  }

  function borrarLote(lote) { Alert.alert('Eliminar lote', `¿Quieres eliminar “${lote.nombre}” y sus registros de este dispositivo?`, [{ text: 'Cancelar', style: 'cancel' }, { text: 'Eliminar', style: 'destructive', onPress: async () => { for (const notificationId of (lote.notificationIds || [])) await Notifications.cancelScheduledNotificationAsync(notificationId).catch(() => {}); setLotes(prev => prev.filter(l => l.id !== lote.id)); if (loteActivo === lote.id) setLoteActivo(''); } }]); }

  const nacimientoEstimado = useMemo(() => { if (!activo) return ''; const d = parseFecha(activo.fecha); if (!d) return ''; d.setDate(d.getDate() + diasTotal - 1); return d.toLocaleDateString('es-CR', { day: 'numeric', month: 'long', year: 'numeric' }); }, [activo, diasTotal]);

  const Btn = ({ children, onPress, secondary = false, small = false }) => <TouchableOpacity onPress={onPress} style={[styles.button, secondary && styles.buttonSecondary, small && styles.buttonSmall]}><Text style={[styles.buttonText, secondary && styles.buttonSecondaryText]}>{children}</Text></TouchableOpacity>;
  const SectionTitle = ({ children }) => <Text style={styles.sectionTitle}>{children}</Text>;

  return <View style={styles.screen}><StatusBar style="dark"/><ScrollView contentContainerStyle={styles.container}>
    <View style={styles.header}><View><Text style={styles.brand}>🥚 Incubadora</Text><Text style={styles.tagline}>Cada huevo, una nueva vida</Text></View><View style={styles.headerBadge}><Text style={styles.headerBadgeText}>🐣</Text></View></View>
    <View style={styles.nav}>{['Inicio', 'Embriones', 'Cuidados', 'Galería'].map(t => <TouchableOpacity key={t} onPress={() => setTab(t)} style={[styles.navItem, tab === t && styles.navItemActive]}><Text style={[styles.navText, tab === t && styles.navTextActive]}>{t}</Text></TouchableOpacity>)}</View>

    {tab === 'Inicio' && <>
      <View style={styles.hero}><Text style={styles.heroEyebrow}>TU GRANJA, MÁS ORGANIZADA</Text><Text style={styles.heroTitle}>Cuida cada etapa de la incubación.</Text><Text style={styles.heroText}>Registra lotes, sigue los días y recibe recordatorios en tu dispositivo.</Text><Btn onPress={() => setTab('Nuevo lote')}>＋ Registrar nuevo lote</Btn></View>
      <SectionTitle>Mis incubaciones</SectionTitle>
      {cargando ? <Text style={styles.muted}>Cargando tus datos…</Text> : lotes.length === 0 ? <View style={styles.empty}><Text style={styles.emptyEmoji}>🪺</Text><Text style={styles.cardTitle}>Todavía no tienes lotes</Text><Text style={styles.muted}>Registra el primer lote para empezar a llevar el control.</Text><Btn onPress={() => setTab('Nuevo lote')}>Crear primer lote</Btn></View> : lotes.map(l => { const n = ESPECIES[l.especie]?.dias || 21; const dia = diaIncubacion(l.fecha); return <TouchableOpacity key={l.id} onPress={() => setLoteActivo(l.id)} style={[styles.lotCard, activo?.id === l.id && styles.lotCardSelected]}><View style={styles.lotTop}><Text style={styles.lotEmoji}>{ESPECIES[l.especie]?.emoji || '🥚'}</Text><View style={{ flex: 1 }}><Text style={styles.cardTitle}>{l.nombre}</Text><Text style={styles.muted}>{l.especie} · Inicio {l.fecha}</Text></View><Text style={styles.dayPill}>{Math.min(dia, n)}/{n}</Text></View><View style={styles.progressBg}><View style={[styles.progressFill, { width: `${Math.min(100, dia / n * 100)}%` }]} /></View><Text style={styles.lotFoot}>{Math.max(0, n - dia)} días aproximados restantes · {l.cantidad ? `${l.cantidad} huevos` : 'Cantidad no indicada'}</Text><View style={styles.inlineButtons}><Btn small secondary onPress={() => { setLoteActivo(l.id); setTab('Cuidados'); }}>Control diario</Btn><Btn small secondary onPress={() => programarAvisos(l)}>🔔 Avisos</Btn><TouchableOpacity onPress={() => borrarLote(l)}><Text style={styles.deleteText}>Eliminar</Text></TouchableOpacity></View></TouchableOpacity>; })}
      {activo && <View style={styles.card}><SectionTitle>Lote seleccionado</SectionTitle><Text style={styles.cardTitle}>{activo.nombre}</Text><Text style={styles.muted}>Eclosión estimada: {nacimientoEstimado}</Text><Text style={styles.muted}>Duración orientativa: {diasTotal} días. La fecha puede variar según especie, huevos y condiciones reales.</Text></View>}
      <SectionTitle>Accesos rápidos</SectionTitle><View style={styles.quickGrid}><TouchableOpacity style={styles.quickCard} onPress={() => setTab('Embriones')}><Text style={styles.quickEmoji}>🔬</Text><Text style={styles.quickTitle}>Desarrollo del embrión</Text></TouchableOpacity><TouchableOpacity style={styles.quickCard} onPress={() => setTab('Cuidados')}><Text style={styles.quickEmoji}>🌡️</Text><Text style={styles.quickTitle}>Temperatura y humedad</Text></TouchableOpacity></View>
    </>}

    {tab === 'Nuevo lote' && <View style={styles.card}><SectionTitle>Nuevo lote de incubación</SectionTitle><Text style={styles.label}>Nombre del lote</Text><TextInput style={styles.input} value={nombre} onChangeText={setNombre} placeholder="Ej. Lote de octubre"/><Text style={styles.label}>Especie</Text><View style={styles.speciesGrid}>{Object.keys(ESPECIES).map(s => <TouchableOpacity key={s} onPress={() => setEspecie(s)} style={[styles.speciesChip, especie === s && styles.speciesChipActive]}><Text style={styles.speciesEmoji}>{ESPECIES[s].emoji}</Text><Text style={[styles.speciesText, especie === s && styles.speciesTextActive]}>{s}</Text><Text style={[styles.speciesDays, especie === s && styles.speciesTextActive]}>{ESPECIES[s].dias} días*</Text></TouchableOpacity>)}</View><Text style={styles.label}>Fecha de inicio (AAAA-MM-DD)</Text><TextInput style={styles.input} value={fecha} onChangeText={setFecha} placeholder="2026-10-27" autoCapitalize="none"/><Text style={styles.label}>Horarios para recordatorios (hora 24 h)</Text><TextInput style={styles.input} value={horariosRecordatorio} onChangeText={setHorariosRecordatorio} placeholder="08:00, 14:00, 20:00" autoCapitalize="none"/><Text style={styles.smallNote}>Puedes poner una hora al día o varias, separadas por comas. Ejemplo: 08:00 o 08:00, 14:00, 20:00. Se usarán para los recordatorios de revisión y volteo hasta el día anterior al día orientativo para detenerlo.</Text><Text style={styles.label}>Cantidad de huevos (opcional)</Text><TextInput style={styles.input} value={cantidad} onChangeText={setCantidad} placeholder="Ej. 24" keyboardType="number-pad"/><Text style={styles.label}>Notas (opcional)</Text><TextInput style={[styles.input, styles.multiline]} value={notas} onChangeText={setNotas} placeholder="Raza, origen, observaciones…" multiline/><Text style={styles.smallNote}>*Duraciones aproximadas. Confirma los parámetros adecuados para tu especie y tu incubadora.</Text><Btn onPress={agregarLote}>Guardar lote</Btn><Btn secondary onPress={() => setTab('Inicio')}>Cancelar</Btn></View>}

    {tab === 'Embriones' && <>
      <View style={styles.hero}><Text style={styles.heroTitle}>Desarrollo del embrión</Text><Text style={styles.heroText}>Guía educativa orientativa para huevos de gallina. Los tiempos varían y no sustituyen la observación ni una guía veterinaria o técnica.</Text></View>
      <View style={styles.notice}><Text style={styles.noticeTitle}>🔦 Ovoscopia segura</Text><Text style={styles.noticeText}>Hazla en un lugar oscuro con una luz adecuada, manipula el huevo con manos limpias y evita enfriarlo demasiado. No sacudas ni gires bruscamente el huevo.</Text></View>
      {ETAPAS_GALLINA.map((e, i) => <View key={e.titulo} style={styles.stageCard}><View style={styles.stageIcon}><Text style={{ fontSize: 25 }}>{['🧬','❤️','🐣','🪶','🥚','🪺','🐥'][i]}</Text></View><View style={{ flex: 1 }}><Text style={styles.stageDay}>DÍA {e.desde}{e.hasta !== e.desde ? `–${e.hasta}` : ''}</Text><Text style={styles.cardTitle}>{e.titulo}</Text><Text style={styles.bodyText}>{e.detalle}</Text></View></View>)}
      <View style={styles.notice}><Text style={styles.noticeTitle}>Importante</Text><Text style={styles.noticeText}>La app no puede ver el embrión ni diagnosticar su viabilidad. La guía visual es educativa; usa la ovoscopia para observar, no para garantizar que un huevo eclosionará.</Text></View>
    </>}

    {tab === 'Cuidados' && <>
      <View style={styles.hero}><Text style={styles.heroTitle}>Control diario</Text><Text style={styles.heroText}>Registra las lecturas que observas en tu equipo. La aplicación no mide temperatura ni humedad automáticamente.</Text></View>
      {!activo ? <View style={styles.empty}><Text style={styles.emptyEmoji}>🌡️</Text><Text style={styles.cardTitle}>Selecciona o crea un lote</Text><Btn onPress={() => setTab('Nuevo lote')}>Crear lote</Btn></View> : <>
        <View style={styles.card}><Text style={styles.muted}>Lote seleccionado</Text><Text style={styles.cardTitle}>{activo.nombre} · {activo.especie}</Text><Text style={styles.muted}>Día {diaActual} de aproximadamente {diasTotal}</Text><View style={styles.metrics}><View style={styles.metric}><Text style={styles.metricEmoji}>🌡️</Text><Text style={styles.metricValue}>{ESPECIES[activo.especie]?.temp}</Text><Text style={styles.muted}>Referencia general</Text></View><View style={styles.metric}><Text style={styles.metricEmoji}>💧</Text><Text style={styles.metricValue}>Humedad</Text><Text style={styles.muted}>{ESPECIES[activo.especie]?.humedad}</Text></View></View><Text style={styles.smallNote}>Las referencias no son una medición. Sigue las instrucciones del fabricante y una guía fiable específica para la especie.</Text></View>
        <View style={styles.card}><SectionTitle>Registrar lectura</SectionTitle><Text style={styles.label}>Temperatura observada (°C)</Text><TextInput style={styles.input} value={temp} onChangeText={setTemp} keyboardType="decimal-pad" placeholder="37.5"/><Text style={styles.label}>Humedad observada (%)</Text><TextInput style={styles.input} value={humedad} onChangeText={setHumedad} keyboardType="decimal-pad" placeholder="50"/><Text style={styles.label}>Observaciones (opcional)</Text><TextInput style={styles.input} value={registroNota} onChangeText={setRegistroNota} placeholder="Volteo, ovoscopia, cambios…"/><Btn onPress={guardarRegistro}>Guardar control</Btn></View>
        <SectionTitle>Historial de controles</SectionTitle>{(activo.registros || []).length === 0 ? <Text style={styles.muted}>Aún no hay controles guardados para este lote.</Text> : activo.registros.map(r => <View key={r.id} style={styles.historyRow}><Text style={styles.cardTitle}>Día {r.dia} · {new Date(r.fecha).toLocaleDateString('es-CR')}</Text><Text style={styles.bodyText}>🌡️ {r.temperatura} °C  ·  💧 {r.humedad}%</Text>{r.nota ? <Text style={styles.muted}>{r.nota}</Text> : null}</View>)}
      </>}
      <View style={styles.notice}><Text style={styles.noticeTitle}>🔔 Sobre los avisos</Text><Text style={styles.noticeText}>Los recordatorios son locales en este dispositivo y requieren permiso. Si cambias de teléfono, borras los datos o el sistema restringe notificaciones, tendrás que configurarlos de nuevo. No son alertas de sensores.</Text></View>
    </>}

    {tab === 'Galería' && <><View style={styles.hero}><Text style={styles.heroTitle}>Galería de aves y equipo</Text><Text style={styles.heroText}>Imágenes de referencia cargadas desde Internet; se necesita conexión para verlas.</Text></View><View style={styles.photoGrid}>{FOTOS.map(f => <View key={f.titulo} style={styles.photoCard}><Image source={{ uri: f.uri }} style={styles.photo} resizeMode="cover" onError={() => {}}/><Text style={styles.cardTitle}>{f.emoji} {f.titulo}</Text><Text style={styles.muted}>{f.subtitulo}</Text></View>)}</View><View style={styles.notice}><Text style={styles.noticeTitle}>Fotos específicas de patas y embriones</Text><Text style={styles.noticeText}>Esta versión incluye una galería inicial de referencia. Para asegurar que cada foto sea correcta y esté bien identificada, la galería puede ampliarse con fotografías verificadas de patas, razas, ovoscopia y etapas embrionarias.</Text></View></>}

    <Text style={styles.footer}>Incubadora · Para cuidar cada nacimiento 🐣</Text><Text style={styles.footerTiny}>Los datos se guardan en este dispositivo. Haz respaldos antes de cambiar de teléfono.</Text>
  </ScrollView></View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F5F7F2' }, container: { padding: 18, paddingBottom: 36 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, marginBottom: 16 }, brand: { fontSize: 28, fontWeight: '900', color: '#174D37' }, tagline: { color: '#6D806F', marginTop: 3, fontSize: 13 }, headerBadge: { width: 48, height: 48, borderRadius: 16, backgroundColor: '#DCEFE1', alignItems: 'center', justifyContent: 'center' }, headerBadgeText: { fontSize: 27 }, nav: { flexDirection: 'row', flexWrap: 'wrap', backgroundColor: '#E8EEE6', padding: 4, borderRadius: 14, marginBottom: 18, gap: 3 }, navItem: { flexGrow: 1, paddingVertical: 10, paddingHorizontal: 11, borderRadius: 10, alignItems: 'center' }, navItemActive: { backgroundColor: '#174D37' }, navText: { color: '#526858', fontWeight: '700', fontSize: 12 }, navTextActive: { color: '#FFFFFF' }, hero: { backgroundColor: '#E2F0E4', borderRadius: 22, padding: 20, marginBottom: 22 }, heroEyebrow: { color: '#397454', fontSize: 10, fontWeight: '900', letterSpacing: 1.1, marginBottom: 9 }, heroTitle: { fontSize: 24, lineHeight: 29, color: '#174D37', fontWeight: '900', marginBottom: 8 }, heroText: { color: '#526858', lineHeight: 20, marginBottom: 15 }, button: { backgroundColor: '#176342', paddingVertical: 13, paddingHorizontal: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 }, buttonText: { color: '#FFFFFF', fontWeight: '800', fontSize: 14 }, buttonSecondary: { backgroundColor: '#EEF4EE', borderWidth: 1, borderColor: '#D6E2D6' }, buttonSecondaryText: { color: '#245A3E' }, buttonSmall: { paddingVertical: 8, paddingHorizontal: 10, marginTop: 0, marginRight: 6 }, sectionTitle: { color: '#243B2D', fontWeight: '900', fontSize: 18, marginBottom: 12, marginTop: 2 }, muted: { color: '#718075', fontSize: 12, lineHeight: 18 }, card: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 17, marginBottom: 18, borderWidth: 1, borderColor: '#E7ECE5' }, empty: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 24, alignItems: 'center', marginBottom: 20, borderWidth: 1, borderColor: '#E7ECE5' }, emptyEmoji: { fontSize: 36, marginBottom: 8 }, cardTitle: { color: '#25392C', fontSize: 15, fontWeight: '800', marginBottom: 4 }, lotCard: { backgroundColor: '#FFFFFF', borderRadius: 17, padding: 15, marginBottom: 12, borderWidth: 1, borderColor: '#E7ECE5' }, lotCardSelected: { borderColor: '#5B9A6E', borderWidth: 1.5 }, lotTop: { flexDirection: 'row', alignItems: 'center', gap: 10 }, lotEmoji: { fontSize: 28 }, dayPill: { color: '#176342', backgroundColor: '#E2F0E4', paddingHorizontal: 9, paddingVertical: 6, borderRadius: 9, fontWeight: '900', fontSize: 12 }, progressBg: { height: 7, backgroundColor: '#E9EEE7', borderRadius: 8, marginTop: 13, overflow: 'hidden' }, progressFill: { height: 7, backgroundColor: '#4E9668', borderRadius: 8 }, lotFoot: { color: '#718075', fontSize: 11, marginTop: 7 }, inlineButtons: { flexDirection: 'row', alignItems: 'center', marginTop: 12, flexWrap: 'wrap', gap: 5 }, deleteText: { color: '#A44940', fontSize: 12, padding: 7 }, quickGrid: { flexDirection: 'row', gap: 10, marginBottom: 18 }, quickCard: { flex: 1, backgroundColor: '#FFFFFF', padding: 15, borderRadius: 16, borderWidth: 1, borderColor: '#E7ECE5' }, quickEmoji: { fontSize: 26, marginBottom: 10 }, quickTitle: { color: '#294232', fontWeight: '800', fontSize: 13 }, label: { color: '#45584A', fontWeight: '700', fontSize: 12, marginTop: 12, marginBottom: 6 }, input: { backgroundColor: '#FAFCF9', borderColor: '#DCE5DB', borderWidth: 1, borderRadius: 11, paddingHorizontal: 12, paddingVertical: 12, color: '#243B2D', fontSize: 14 }, multiline: { minHeight: 72, textAlignVertical: 'top' }, speciesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 2 }, speciesChip: { width: '31%', minWidth: 90, backgroundColor: '#F4F7F2', borderColor: '#E1E8DE', borderWidth: 1, borderRadius: 12, padding: 10, alignItems: 'center' }, speciesChipActive: { backgroundColor: '#176342', borderColor: '#176342' }, speciesEmoji: { fontSize: 22 }, speciesText: { color: '#34513D', fontWeight: '800', fontSize: 12, marginTop: 3 }, speciesDays: { color: '#7A897C', fontSize: 10, marginTop: 3 }, speciesTextActive: { color: '#FFFFFF' }, smallNote: { color: '#879188', fontSize: 10, lineHeight: 15, marginTop: 12, marginBottom: 8 }, notice: { backgroundColor: '#FFF8E8', borderColor: '#F1E5C5', borderWidth: 1, padding: 15, borderRadius: 15, marginBottom: 15 }, noticeTitle: { color: '#735822', fontWeight: '900', marginBottom: 6 }, noticeText: { color: '#776B50', fontSize: 12, lineHeight: 18 }, stageCard: { flexDirection: 'row', backgroundColor: '#FFFFFF', borderRadius: 15, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#E7ECE5', gap: 12 }, stageIcon: { width: 45, height: 45, borderRadius: 14, backgroundColor: '#EDF4E9', alignItems: 'center', justifyContent: 'center' }, stageDay: { color: '#43805A', fontWeight: '900', fontSize: 10, marginBottom: 3 }, bodyText: { color: '#69766B', fontSize: 12, lineHeight: 18, marginTop: 3 }, metrics: { flexDirection: 'row', gap: 10, marginTop: 15 }, metric: { flex: 1, backgroundColor: '#F4F8F2', borderRadius: 13, padding: 12 }, metricEmoji: { fontSize: 22, marginBottom: 7 }, metricValue: { color: '#284C35', fontWeight: '900', fontSize: 13, marginBottom: 4 }, historyRow: { backgroundColor: '#FFFFFF', borderRadius: 13, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: '#E7ECE5' }, photoGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 10 }, photoCard: { width: '48%', backgroundColor: '#FFFFFF', padding: 9, borderRadius: 15, marginBottom: 5, borderWidth: 1, borderColor: '#E7ECE5' }, photo: { width: '100%', height: 125, backgroundColor: '#E8EEE6', borderRadius: 10, marginBottom: 9 }, footer: { textAlign: 'center', color: '#50705A', fontWeight: '800', marginTop: 25 }, footerTiny: { textAlign: 'center', color: '#8A968B', fontSize: 10, lineHeight: 15, marginTop: 6, marginBottom: 8 },
});
